# Sauriil Dark Archive — WinRAR Theme Design Specification

## Theme Identity

**Theme name:** Sauriil Dark Archive 128x128
**Final archive filename:** `SauriilDarkArchive.128x128.theme.rar`
**Target toolbar icon size:** `128x128`
**Core phrase:** “A Sithis-sealed Daedric archive-machine: a black reliquary for compressed worlds.”

The theme is a semi-realistic dark fantasy utility interface for WinRAR. It should feel like a functional archive system built from forged black steel, ash parchment, red ritual seals, Daedric-like glyphwork, and restrained occult geometry.

Primary identity: **red/black Sithis-Dark Brotherhood ritual**.
Secondary identity: **Velothi / Tribunal occult archivist**.
Tertiary identity: **subtle High Elf / Aldmeri refinement** through symmetry, pale-gold filigree, disciplined proportions, and elegant angular geometry only.

The theme must remain usable as a Windows utility theme. Icons must prioritize silhouette, command recognition, and consistent toolbar readability over illustration density.

## Official WinRAR Packaging Target

A WinRAR theme is implemented as a `.theme.rar` archive containing alternative graphics plus `winrar_theme_description.txt`; the description file must be located in the archive root. RARLAB specifies the theme filename format as `basename.anytext.theme.rar`, with the `basename` used as the installed theme folder name. ([WinRAR][1])

The implementation target is:

```txt
SauriilDarkArchive.128x128.theme.rar
```

Required root metadata file:

```txt
winrar_theme_description.txt
```

Toolbar assets must be placed in:

```txt
Toolbar/
```

Use PNG for toolbar graphics where possible. RARLAB notes that although its examples name BMP files, PNG files are accepted for WinRAR 5.60 and newer; toolbar buttons may use any reasonable size, and WinRAR detects toolbar dimensions automatically from the Add asset. ([WinRAR][1])

`Toolbar/Add.png` must exist. RARLAB states that most graphics can be omitted, but `Add.bmp` is the exception because WinRAR uses it to detect toolbar button dimensions; for this PNG-based theme, the required equivalent is `Add.png`. ([WinRAR][1])

A single theme file must contain only one toolbar-button set. This specification targets one set only: `128x128`. ([WinRAR][1])

Themes are installed by opening the theme archive in WinRAR, then selected through `Options > Themes`. ([WinRAR][2])

## Visual Design System

The full set should read as one artifact system: a black ritual archive interface used by an occult Listener-archivist.

Core visual hierarchy:

1. **Black forged structure** — archive boxes, gates, locks, tablets, shields.
2. **Blood-red ritual state** — seals, warnings, destructive action, protected/locked status.
3. **Parchment utility layer** — documents, comments, reports, extraction sheets, instruction strips.
4. **Velothi/Tribunal geometry** — triune divisions, ash-script margins, angular sacred-machine lines.
5. **Cyan Aetherius system-light** — inspection, verification, motion paths, active magical edges.
6. **Aldmeri restraint** — tiny pale-gold trim, symmetry, fine filigree, disciplined icon balance.

The design must avoid generic “neon dark fantasy.” It should feel ancient, precise, and functional: black metal archive components with ritual control markings.

Scale priorities:

```txt
128x128: semi-realistic texture, engraving, parchment fibers, small glyph clusters.
32x32: clear command silhouette and red/cyan state accents.
16x16: only core object shape and color-state logic must remain important.
```

Do not copy official Elder Scrolls symbols, faction logos, maps, UI elements, Daedric Prince symbols, Dark Brotherhood handprints, Shadowmarks, Aldmeri crests, or existing game art. Create original mythic-adjacent iconography.

## Palette

| Role              |       HEX | Usage                                             |
| ----------------- | --------: | ------------------------------------------------- |
| Void Black        | `#050406` | dominant background, negative space, icon shadows |
| Ritual Black      | `#0B080A` | icon body, dark cloth, sealed archive surfaces    |
| Charcoal Obsidian | `#171216` | secondary dark panels and inner icon planes       |
| Blood Red         | `#8B1116` | dominant accent, warning, delete, forbidden seal  |
| Deep Sithis Red   | `#4A0508` | dark red shadow, dried blood, ritual marks        |
| Fresh Seal Red    | `#C51F2A` | small high-contrast red highlights only           |
| Aged Steel        | `#8D8580` | main metal highlights                             |
| Dark Steel        | `#3E3A38` | engraved metal base                               |
| Oxidized Bronze   | `#7A5A35` | old artifact edges                                |
| Tribunal Gold     | `#B08A3C` | restrained Velothi/Tribunal ornament              |
| Aldmeri Pale Gold | `#D6BC73` | very subtle high-elven refinement                 |
| Parchment Bone    | `#C8B88F` | scrolls, labels, documents, warmth                |
| Burnt Parchment   | `#7A6240` | parchment shadows                                 |
| Ash Grey          | `#6C6860` | Velothi ash, worn stone, muted scripture texture  |
| Aether Cyan       | `#25D6C5` | secondary glow, magical edges                     |
| Cold Aether Blue  | `#2A64D6` | rare blue glyphfire lines                         |
| Ghost Green       | `#2E9C78` | extremely subtle cosmology residue                |
| Void Violet       | `#3A1E54` | rare Oblivion background tint                     |

Usage rules:

* Red/black must dominate roughly **70–80%** of the accent identity.
* Blue/cyan must stay secondary, roughly **10–20%**, used for magical inspection, pathing, detection, edge-light, or active system feedback.
* Parchment warmth should appear on document-related assets, not dominate the theme.
* Gold must be restrained. Use it for thin trim, corner filigree, triune ticks, and elegant high-elven refinement.
* Avoid saturated rainbow color except for tiny stained-glass fragments where specifically useful.
* No icon may be brighter overall than `Toolbar/Delete.png` or `Toolbar/SFX.png`.

## Typography and Glyph Use

Use the uploaded **Daedra-style font** only as decorative glyph material.

Rules:

* Decorative only; never required for command comprehension.
* Use as engraved border glyphs, seal marks, tiny ring inscriptions, parchment-margin marks, and metal plaque texture.
* No readable functional labels inside the icon art.
* No visible `Aetheris`, `Jakub`, or `Sauriil` mark inside image assets.
* The author name may appear only in `winrar_theme_description.txt`.
* If the design tool cannot load the font, manually imitate angular Daedric-like strokes.
* Do not distribute, embed, or share the font file unless its license explicitly allows it.
* Limit each toolbar icon to **no more than two tiny glyph clusters**.

## Shape Language

Use:

* circular ritual seals,
* nested cosmology rings,
* Imperial City-like radial planning geometry,
* triangular Daedric cuts,
* angular glyph strokes,
* black metal archive boxes,
* parchment tabs and scrolls,
* red wax/blood seals,
* Velothi ash-script panels,
* Tribunal-like triune geometry,
* pale-gold filigree,
* mask-like silhouettes,
* engraved borders,
* stained-glass slivers,
* lock, gate, vault, and reliquary motifs.

Avoid:

* direct Elder Scrolls faction symbols,
* direct Daedric Prince symbols,
* copied Dark Brotherhood handprint,
* copied Shadowmarks,
* copied Aldmeri Dominion eagle/crest,
* full manuscript pages that become unreadable noise,
* repeated outer silhouettes across toolbar icons,
* decorative clutter that weakens command readability.

## Rendering Style

Use **semi-realistic rendered icons**, not flat vectors.

Required qualities:

* forged dark steel,
* engraved metal scratches,
* parchment fibers,
* worn bronze edges,
* restrained pale-gold filigree,
* red wax or blood-seal accents,
* subtle cyan/blue rim light,
* realistic ambient occlusion,
* transparent background,
* soft cast shadow under each object,
* crisp silhouette,
* warm parchment contrast against black metal.

Avoid:

* flat minimal UI icons,
* glossy app-store plastic,
* cartoon props,
* over-rendered photorealistic clutter,
* heavy smoke,
* excessive bloom,
* full miniature scenes that fail at 32x32.

Lighting:

```txt
Primary light: cold upper-left.
Secondary glow: small cyan magical edge-light.
Red material light: localized seal/warning glow only.
Shadow: soft, low, consistent across all toolbar icons.
```

## Narrative Identity

The theme represents a personal WinRAR archive system used by a **Velothi-Tribunal occult Listener** who serves the silence of Sithis, preserves forbidden records, and compresses worlds into sealed relics.

The icons are not ordinary toolbar buttons; each is a small ritual object from a black archive-machine:

* `Add` seals a new world into the reliquary.
* `Extract` opens a ritual gate and releases parchment records.
* `Test` inspects the seal through an occult lens.
* `Delete` cuts a forbidden archive plate into the void.
* `Repair` binds a cracked seal with cyan and bronze restoration lines.
* `Protect` raises a ward over compressed knowledge.
* `Wizard` is not a generic wizard; it is a masked Velothi Listener-guide.
* `Benchmark` is an Imperial-city-like cosmology gauge measuring archive force.

The result should feel precise, disciplined, and ritualized. Assassin secrecy must be present, but the theme should read as **occult archivist**, not crude murderer.

## Asset Folder Structure

```txt
SauriilDarkArchive/
├─ winrar_theme_description.txt
├─ AboutLogo.png
├─ DiskOff.ico
├─ DiskOn.ico
├─ DragCopy.cur
├─ DragMove.cur
├─ DragNo.cur
├─ Estimate.png
├─ FolderUp.png
├─ PasswordOff.ico
├─ PasswordOn.ico
├─ RAR.ico
├─ REV.ico
├─ Setup.ico
├─ SFX.ico
├─ SFXLogo.png
├─ WizardLogo.png
└─ Toolbar/
   ├─ Add.png
   ├─ Benchmark.png
   ├─ Comment.png
   ├─ Convert.png
   ├─ Delete.png
   ├─ Exit.png
   ├─ Extract.png
   ├─ ExtractTo.png
   ├─ Find.png
   ├─ Info.png
   ├─ Lock.png
   ├─ Print.png
   ├─ Protect.png
   ├─ Repair.png
   ├─ Report.png
   ├─ SFX.png
   ├─ Test.png
   ├─ View.png
   ├─ VirusScan.png
   └─ Wizard.png
```

## winrar_theme_description.txt

RARLAB specifies `winrar_theme_description.txt` as a plain ASCII text file in the root, containing `title=` and `about=` commands. The `about=` field may use one `\n` to split into two lines, but should not use more than one or become too long for the About dialog. ([WinRAR][1])

Use this exact content:

```txt
title=Sauriil Dark Archive 128x128
about=Sauriil Dark Archive by Aetheris.\nSithis-sealed Daedric archive-machine for WinRAR.
```

## Root Asset Specifications

| Filename          | Purpose                      | Visual Metaphor                                       | Main Silhouette                                                        | Material/Color Treatment                                                                                   | Accent                                                 | Readability Requirement                               | Designer Notes                                                                   |
| ----------------- | ---------------------------- | ----------------------------------------------------- | ---------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------- | ------------------------------------------------------ | ----------------------------------------------------- | -------------------------------------------------------------------------------- |
| `AboutLogo.png`   | About dialog logo            | Horizontal black reliquary plaque for the whole theme | Wide rectangular plaque with central red seal and faint cosmology ring | Void black / ritual black plaque, aged steel bevels, ash parchment backing glow, pale-gold border filigree | Blood red central seal, tiny cyan ring glints          | Must read as premium theme banner, not a toolbar icon | No visible author signature. Include Daedric-like margin glyphs as texture only. |
| `DiskOff.ico`     | Inactive disk status icon    | Cold unlit archive coin                               | Small circular coin/seal                                               | Dark steel, ash grey, low contrast, no active glow                                                         | Nearly black red groove only                           | At 16x16, must read as inactive disk/coin             | Keep simple; no complex script at 16x16.                                         |
| `DiskOn.ico`      | Active disk status icon      | Activated archive coin                                | Circular coin with lit inner ring                                      | Dark steel rim, aged steel highlight, inner red-black seal                                                 | Small cyan edge glint and red active center            | At 16x16, must clearly differ from `DiskOff.ico`      | Increase center brightness slightly but avoid neon.                              |
| `DragCopy.cur`    | Drag-copy cursor             | Ritual cursor with copy path                          | Sharp angled cursor plus duplicate parchment sliver                    | Black pointer body, aged steel edge, parchment mini-sheet                                                  | Cyan copy line                                         | Cursor hotspot must remain precise                    | Hotspot at pointer tip. Cyan line indicates copy action.                         |
| `DragMove.cur`    | Drag-move cursor             | Ritual cursor with movement path                      | Sharp angled cursor with single moving archive shard                   | Black pointer, dark steel bevel, small red archive shard                                                   | Cyan motion streak                                     | Must differ from `DragCopy.cur` at 32x32              | Hotspot at pointer tip. Use one object, not duplicate sheets.                    |
| `DragNo.cur`      | Drop-prohibited cursor       | Forbidden ritual denial mark                          | Sharp cursor plus red broken seal / slash                              | Black pointer, dark steel edge, red prohibition ring/slash                                                 | Fresh Seal Red                                         | Must instantly read as “not allowed”                  | Hotspot at pointer tip. Red mark must dominate.                                  |
| `Estimate.png`    | Estimate compression image   | Calculation astrolabe                                 | Circular measuring astrolabe with radial rings                         | Dark steel rings, bronze pivots, parchment tick inserts                                                    | Red needle, cyan tick glints                           | Must read as measurement/calculation at small size    | Use Imperial City-like radial geometry without copying maps.                     |
| `FolderUp.png`    | Go up one folder             | Parchment folder and stair-glyph                      | Small upward folder/stair symbol                                       | Parchment bone folder, burnt edges, dark metal hinge                                                       | Red upward seal mark, tiny cyan edge                   | At 16x16, upward direction must be clear              | Keep silhouette very simple.                                                     |
| `PasswordOff.ico` | Inactive password status     | Dim sealed lock                                       | Small padlock                                                          | Dark steel, charcoal body, unlit shackle                                                                   | Deep Sithis Red inactive groove                        | Must read as locked/password but inactive             | Low glow; avoid cyan except tiny metal edge.                                     |
| `PasswordOn.ico`  | Active password status       | Active warded lock                                    | Padlock with lit seal                                                  | Black iron lock, aged steel highlights                                                                     | Blood Red ward center, cyan shackle edge               | Must clearly differ from `PasswordOff.ico`            | Red ward glow is primary.                                                        |
| `RAR.ico`         | General RAR archive icon     | Black-metal archive cube/chest                        | Compact archive cube/chest                                             | Ritual black metal, dark steel bevels, bronze corner wear                                                  | Red compression seal, tiny cyan rim, triangular groove | At 16x16, must still read as archive object           | This is the core identity icon.                                                  |
| `REV.ico`         | Recovery volume icon         | Cracked restored archive shard                        | Broken shard or partial cube with repair veins                         | Black metal fragment, aged steel fracture edges                                                            | Cyan repair veins, red restored seal                   | Must read as recovery/restoration, not deletion       | Use visible binding lines to distinguish from `Delete`.                          |
| `Setup.ico`       | Setup/install icon           | Ritual installation disk/gear                         | Gear-disk with parchment instruction strip                             | Dark steel gear, bronze outer teeth, parchment band                                                        | Red registration mark, pale-gold rim                   | Must read as installer/setup at 16–32px               | Do not resemble Benchmark; use gear teeth, not gauge needle.                     |
| `SFX.ico`         | Self-extracting archive icon | Self-opening rune-box                                 | Archive box opening with ignition burst                                | Black metal box, red-lit interior                                                                          | Red ignition, cyan path edge                           | Must read as executable/self-opening archive          | Stronger glow allowed, but not brighter than toolbar `SFX`.                      |
| `SFXLogo.png`     | SFX module logo              | Vertical archive gate banner                          | Tall black-and-parchment banner with gate                              | Ritual black frame, parchment panel, steel gate                                                            | Red ignition glyphs, cyan gate seam                    | Must fit vertical logo role                           | Avoid text dependency. Use one central gate motif.                               |
| `WizardLogo.png`  | Wizard dialog logo           | Masked Velothi Listener-guide                         | Hooded/masked bust or guide sigil                                      | Black cloth, dark steel mask, parchment halo/backplate                                                     | Cyan hand/glyphfire, red chest seal, pale-gold trim    | Must read as guide/assistant, not generic mage        | Keep face abstract; no copied masks or faction symbols.                          |

## Toolbar Asset Specifications

| Filename                | Command    | Visual Metaphor                                       | Main Silhouette                                                           | Material/Color Treatment                                                                 | Accent                                                    | Readability Requirement                          | Designer Notes                                                                     |
| ----------------------- | ---------- | ----------------------------------------------------- | ------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------- | --------------------------------------------------------- | ------------------------------------------------ | ---------------------------------------------------------------------------------- |
| `Toolbar/Add.png`       | Add        | Sealed archive chest receiving a new compressed world | Rectangular reliquary chest with readable plus-glyph                      | Red-black metal body, dark steel hinges, red wax seal on lid, pale-gold corner filigree  | Cyan Daedric-style plus-glyph                             | Plus must be immediately readable at 32x32       | This asset defines toolbar dimensions; must be exactly 128x128.                    |
| `Toolbar/Extract.png`   | Extract    | Archive gate opening outward and releasing records    | Open circular gate with parchment sheets emerging                         | Black steel gate, cracked red ritual ring, parchment bone sheets with ash-script texture | Cyan light inside gate                                    | Must read as outward extraction motion           | Distinct from `ExtractTo`: no destination mark.                                    |
| `Toolbar/ExtractTo.png` | Extract To | Files flowing to a marked destination sigil           | Diagonal flow from small archive opening to folder-stone/destination seal | Parchment files, dark destination stone/folder, red destination seal                     | Thin cyan path line                                       | Destination target must be clear at 32x32        | Use diagonal composition; do not reuse circular gate silhouette as primary.        |
| `Toolbar/Test.png`      | Test       | Occult inspection lens over sealed archive            | Large lens/astrolabe overlapping compact archive                          | Dark steel lens rim, black archive base, red seal under glass                            | Cyan lens glow                                            | Must read as verification/testing, not search    | Add tiny triune verification mark inside lens.                                     |
| `Toolbar/View.png`      | View       | Eye within a cosmology ring                           | Eye-ring silhouette                                                       | Dark steel circular ring, parchment/steel eyelid planes, red iris/core                   | Faint cyan construction lines around ring                 | Must read as view/observe                        | Avoid official eye symbols; keep original geometry.                                |
| `Toolbar/Delete.png`    | Delete     | Forbidden archive plate split by a void-cut           | Jagged broken shard                                                       | Black archive plate, fractured dark steel, strong red cut line                           | Fresh Seal Red and Blood Red dominate                     | Must instantly read as destructive               | Strongest red icon. No copied handprint.                                           |
| `Toolbar/Find.png`      | Find       | Search astrolabe lens                                 | Diagonal handled magnifier / astrolabe-lens                               | Dark steel rim, aged steel handle, black glass lens                                      | Cyan search ray, red target mark                          | Must read as search at 32x32                     | Rim may contain tiny Daedra-font glyphs.                                           |
| `Toolbar/Wizard.png`    | Wizard     | Masked Listener-guide assisting the archive ritual    | Hooded/masked figure silhouette                                           | Black cloth hood, dark metal mask, parchment back halo                                   | Cyan glyphfire hands, red chest seal, thin pale-gold trim | Must read as assistant/guide, not cartoon wizard | Figure silhouette must be unique among toolbar icons.                              |
| `Toolbar/Info.png`      | Info       | Engraved knowledge tablet                             | Upright tablet/slab                                                       | Parchment-metal slab, dark steel frame, ash-grey engraving                               | Red wax seal, cyan inner line                             | Central `i`-like glyph must read as info         | Glyph should be functional but not modern sans-serif typography.                   |
| `Toolbar/Repair.png`    | Repair     | Cracked seal bound back together                      | Round cracked seal with visible stitches/staples                          | Black/red seal disk, bronze/gold repair staples, aged steel rim                          | Cyan binding lines                                        | Must read as repair, not break/delete            | Keep cracks visible but visually “mended.”                                         |
| `Toolbar/Protect.png`   | Protect    | Ward shield over archive box                          | Shield or ward-dome silhouette                                            | Black steel shield, dark archive box behind/inside                                       | Red center seal, cyan protective outline                  | Must read as protection/security                 | Triangular internal geometry may imply Tribunal structure without copying symbols. |
| `Toolbar/Lock.png`      | Lock       | Black iron ward-lock                                  | Padlock silhouette                                                        | Black iron body, aged steel shackle, engraved glyphs                                     | Red ward glow, faint cyan sparks                          | Lock silhouette must dominate                    | Distinct from `Protect`: padlock, not shield.                                      |
| `Toolbar/SFX.png`       | SFX        | Archive box becoming self-opening/executable          | Box bursting open                                                         | Black metal rune-box, red-lit interior, parchment/steel fragments opening outward        | Red ignition dominant, cyan opening outline               | Must read as self-opening archive                | One of the brightest icons, but controlled.                                        |
| `Toolbar/VirusScan.png` | Virus Scan | Corrupted rune trapped in detection circle            | Containment ring around angular hostile rune                              | Cyan inspection ring, black steel clamps, red corrupted angular rune                     | Blood Red corruption, cyan detection                      | Must read as scan/purify, not delete             | Avoid biological/gory virus imagery.                                               |
| `Toolbar/Benchmark.png` | Benchmark  | Cosmology gauge measuring archive force               | Radial gauge disk with needle                                             | Dark steel rings, pale-gold radial divisions, black center                               | Red needle, cyan tick marks                               | Must read as performance/measurement             | Inspired by radial city/cosmology maps, not copied from them.                      |
| `Toolbar/Comment.png`   | Comment    | Parchment note from the archive margin                | Curled parchment note                                                     | Parchment bone sheet, burnt edges, dark ink strokes, small metal clip                    | Red wax seal, cyan underline                              | Must read as note/comment                        | Daedra-font glyphs only in margins.                                                |
| `Toolbar/Convert.png`   | Convert    | Two archive forms rotating through transmutation ring | Dual-object rotation with circular arrows                                 | One red-black archive form, one aged steel/parchment form, dark ring                     | Cyan circular arrows, tiny pale-gold transition node      | Must read as transformation/conversion           | Distinct from `SFX`: rotation, not explosion.                                      |
| `Toolbar/Report.png`    | Report     | Formal assassin archive report                        | Vertical scroll/report sheet                                              | Parchment sheet, dark metal top clip, ash-script bands                                   | Red-blue stamped seal                                     | Must read as report/document                     | More formal and vertical than `Comment`.                                           |
| `Toolbar/Print.png`     | Print      | Manuscript press outputting parchment                 | Horizontal press device with sheet output                                 | Dark steel press block, bronze rollers, parchment output sheet                           | Red stamp mark, tiny cyan mechanical spark                | Must read as printing/output                     | Avoid modern plastic printer shape.                                                |
| `Toolbar/Exit.png`      | Exit       | Ritual doorway receding into void                     | Open doorway/portal                                                       | Black stone/metal doorway, void interior, red near edge                                  | Cyan far inner light                                      | Must read as leaving/exiting                     | Strong depth silhouette; no arrow required unless subtle.                          |

## Unique Silhouette Rules

Each toolbar icon must be recognizable by outer shape before detail is visible:

| Asset           | Unique silhouette anchor                               |
| --------------- | ------------------------------------------------------ |
| `Add.png`       | Closed reliquary chest plus-glyph                      |
| `Extract.png`   | Open circular gate with outward sheets                 |
| `ExtractTo.png` | Diagonal file flow into destination sigil/folder-stone |
| `Test.png`      | Large inspection lens over archive                     |
| `View.png`      | Eye inside cosmology ring                              |
| `Delete.png`    | Jagged broken archive shard                            |
| `Find.png`      | Diagonal handled astrolabe-lens                        |
| `Wizard.png`    | Hooded/masked Listener figure                          |
| `Info.png`      | Upright engraved tablet                                |
| `Repair.png`    | Round cracked seal with binding staples                |
| `Protect.png`   | Shield or ward-dome over archive                       |
| `Lock.png`      | Padlock                                                |
| `SFX.png`       | Rune-box bursting open                                 |
| `VirusScan.png` | Containment ring around corrupted rune                 |
| `Benchmark.png` | Radial gauge disk with needle                          |
| `Comment.png`   | Curled parchment note                                  |
| `Convert.png`   | Two rotating archive forms                             |
| `Report.png`    | Vertical formal scroll/report sheet                    |
| `Print.png`     | Horizontal manuscript press                            |
| `Exit.png`      | Open ritual doorway/portal                             |

Additional rules:

* `Delete`, `Lock`, `Protect`, and `VirusScan` must be visually distinct at 32x32.
* `Extract` and `ExtractTo` may share conceptual family, but not the same silhouette.
* `Find` and `Test` must not both look like generic magnifiers; `Find` uses a handled lens, `Test` uses an inspection lens/astrolabe over an archive.
* `Comment` and `Report` must differ: curled note versus formal vertical scroll.
* `SFX` and `Convert` must differ: burst-open box versus rotating dual-object transmutation.

## Icon Consistency Rules

All icons must share:

* same camera angle: mostly front-facing 3/4 object view,
* same upper-left cold key light,
* same shadow direction and softness,
* same black metal material scale,
* same parchment tone and fiber density,
* same red seal material,
* same cyan glow strength,
* same pale-gold restraint,
* same engraving line thickness,
* same safe margin logic,
* same transparent background treatment.

Toolbar composition rules:

```txt
Canvas: 128x128 px
Background: transparent
Central object occupancy: roughly 72–84%
Safe margin: 4–8 px
Shadow: soft, subtle, consistent
Glyph clusters: maximum 2 per icon
Text dependency: none
Visible signature: none
```

Layer order:

1. transparent canvas,
2. soft shadow / ambient occlusion,
3. base silhouette,
4. dark metal / parchment body,
5. engraved detail,
6. red Sithis ritual accent,
7. Velothi/Tribunal geometric detail,
8. cyan Aetherius edge-light,
9. restrained Aldmeri pale-gold trim,
10. parchment warmth where appropriate,
11. final small highlight,
12. optional Daedra-font micro-glyphs.

## Export Settings

Toolbar PNGs:

```txt
Size: 128x128 px
Format: PNG
Bit depth: 32-bit with alpha
Background: transparent
One toolbar set only: 128x128
Required detection asset: Toolbar/Add.png
```

Root PNGs:

```txt
AboutLogo.png: 256x64 or proportional modern PNG equivalent
Estimate.png: 48x48 or higher if tested
FolderUp.png: 16x16 or scalable PNG if tested
SFXLogo.png: 93x302 or proportional modern PNG equivalent
WizardLogo.png: 64x64
```

ICO files should include:

```txt
16x16
32x32
48x48
optional 128x128
optional 256x256
```

ICO targets:

```txt
DiskOff.ico
DiskOn.ico
PasswordOff.ico
PasswordOn.ico
RAR.ico
REV.ico
Setup.ico
SFX.ico
```

CUR files:

```txt
DragCopy.cur: 32x32, hotspot at pointer tip
DragMove.cur: 32x32, hotspot at pointer tip
DragNo.cur: 32x32, hotspot at pointer tip
```

Exact bitmap/logo sizes may need practical testing in WinRAR. RARLAB notes that many bitmap sizes can be slightly changed without hurting the look, toolbar buttons can use any reasonable size, and toolbar dimensions are detected automatically from the Add asset. ([WinRAR][1])

## Packaging Instructions

1. Create the folder:

```txt
SauriilDarkArchive/
```

2. Place this file in the root:

```txt
SauriilDarkArchive/winrar_theme_description.txt
```

3. Place all root assets in:

```txt
SauriilDarkArchive/
```

4. Place all toolbar assets in:

```txt
SauriilDarkArchive/Toolbar/
```

5. Verify that this file exists:

```txt
SauriilDarkArchive/Toolbar/Add.png
```

6. Verify that all toolbar PNGs are:

```txt
128x128
32-bit PNG with alpha
transparent background
```

7. Compress the contents as a RAR archive.

8. Rename/package the archive as:

```txt
SauriilDarkArchive.128x128.theme.rar
```

9. Install by opening the `.theme.rar` file in WinRAR. RARLAB describes theme installation as opening the downloaded theme archive in WinRAR. ([WinRAR][2])

10. Select the installed theme from:

```txt
Options > Themes
```

## Quality Checklist

* [ ] `winrar_theme_description.txt` exists in root.
* [ ] `winrar_theme_description.txt` uses the exact specified content.
* [ ] `Toolbar/Add.png` exists.
* [ ] Only one toolbar size is included.
* [ ] All toolbar icons are `128x128`.
* [ ] All 20 toolbar icons have unique silhouettes.
* [ ] All PNG files have transparent backgrounds where appropriate.
* [ ] ICO files include required common sizes.
* [ ] CUR files are exported as cursor files with correct hotspots.
* [ ] Red/black dominates the visual identity.
* [ ] Cyan/blue is secondary only.
* [ ] Subtle parchment warmth is present where appropriate.
* [ ] Velothi/Tribunal geometry is visible but not dominant.
* [ ] Aldmeri influence is subtle and restrained.
* [ ] Daedra-style font is used only as decorative glyph detail.
* [ ] No visible author/user mark appears in image assets.
* [ ] No direct Elder Scrolls assets are copied.
* [ ] No direct Dark Brotherhood handprint, Shadowmark, Daedric Prince mark, or Aldmeri crest is copied.
* [ ] Each icon is readable at 32x32.
* [ ] At 16x16, state-critical assets still communicate their core meaning.
* [ ] `Delete`, `Lock`, `Protect`, and `VirusScan` have distinct silhouettes.
* [ ] `Extract` and `ExtractTo` are visually related but structurally distinct.
* [ ] `Find` and `Test` do not collapse into the same magnifier design.
* [ ] Theme archive installs in WinRAR.
* [ ] Theme appears under `Options > Themes`.

## Copyright / Originality Notes

The design may be inspired by dark fantasy, Elder Scrolls-like cosmology, Daedric-style glyphs, archive machinery, ritual parchment, Velothi occult geometry, Sithis-like void ritual, and mythic metalwork.

The final assets must not copy official Elder Scrolls art, UI assets, icons, maps, logos, faction symbols, Daedric Prince symbols, Dark Brotherhood symbols, Shadowmarks, Aldmeri Dominion crests, screenshots, or typography.

Do not use third-party graphics without permission. RARLAB states that if a theme is based on someone else’s graphics, permission from the original graphics copyright owner is required. ([WinRAR][1])

The uploaded Daedra-style font may be referenced as a local design input, but the final workflow must respect its license. Do not distribute, embed, or share the font file unless licensing explicitly permits it.

If the final theme is distributed publicly, all source assets must be original, properly licensed, or used with explicit permission.

[1]: https://www.rarlab.com/themes_new.htm "WinRAR archiver, a powerful tool to process RAR and ZIP files"
[2]: https://www.rarlab.com/themes.htm "WinRAR archiver, a powerful tool to process RAR and ZIP files"
