Sauriil Dark Archive 48x48 HQ - structured WinRAR theme source

Theme-ready folder:
  SauriilDarkArchive/

Final WinRAR theme build steps:
1. Open the SauriilDarkArchive folder.
2. Select the CONTENTS of SauriilDarkArchive, not the folder itself.
3. Right-click > WinRAR > Add to archive...
4. Set archive format to RAR.
5. Name the archive:
   SauriilDarkArchive.48x48.HQ.theme.rar
6. Open that .theme.rar in WinRAR to install it.

Important:
- Toolbar/*.png are 48x48 transparent PNG toolbar icons.
- Root *.ico files are multi-size ICO files for archive/app/root icon use.
- SourcePNGs contains named high-resolution source PNGs for future editing.
- The archive must be a real RAR archive, not a renamed ZIP.
